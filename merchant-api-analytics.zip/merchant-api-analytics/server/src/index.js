const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Pool } = require('pg');
const config = require('./config');

const shopifyRoutes = require('./routes/shopify');
const wcRoutes = require('./routes/woocommerce');
const webhooks = require('./routes/webhooks');

const pool = new Pool({ connectionString: config.DATABASE_URL });

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use((req, res, next) => { req.db = pool; next(); });

app.use('/auth/shopify', shopifyRoutes);
app.use('/auth/woocommerce', wcRoutes);
app.use('/webhooks', webhooks);

app.get('/health', (req, res) => res.json({ ok: true }));

app.listen(config.PORT, () => console.log(`Server running on ${config.PORT}`));
